public class Feedback <T>{
    private T user_feedback;

    Feedback(T user_feedback){
        this.user_feedback = user_feedback;
    }

    public T getUser_feedback(){
        return user_feedback;
    }

    public void setUser_feedback(T user_feedback) {
        this.user_feedback = user_feedback;
    }
}
