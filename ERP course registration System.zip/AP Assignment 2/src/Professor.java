import java.util.ArrayList;
import java.util.Scanner;

public class Professor extends User{
    private String name;
    private String officeHour;
    static String enrollmentLimit;
    static ArrayList<Professor> professorDetails = new ArrayList<>();

    public Professor(String name, String emailId, String password, String officeHour, String enrollmentLimit) {
        super(name, emailId, password);
        this.officeHour = officeHour;
        Professor.enrollmentLimit = enrollmentLimit;
        professorDetails.add(this);
        Main.allUsers.add(this);
    }

//    public String getName(){
//        return name;
//    }

    public void viewCourses(){
        for(Course course : Course.courseList){
            if(course.professor.equals(getName())){
                System.out.println("Course name: " + course.title + " | " + course.courseCode);
                System.out.println("Course timings: " + course.timings);
                System.out.println("Course location: " + course.location);
                System.out.println("*******************************");
            }
        }
    }

    public void manageCourses(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter course code for the course which you want to edit: ");
        String courseCode = sc.nextLine();

        for(Course course : Course.courseList){
            if(course.courseCode.equals(courseCode)){

                while(true){
                    System.out.println("Choose which detail you want to modify: ");
                    System.out.println("1. Syllabus\n2. Class timings\n3. Credits\n4. Prerequisites\n5. Enrollment Limit\n6. Office Hours\n7. Assign Grade to Students\n8. Exit");
                    int inp = Integer.parseInt(sc.nextLine());

                    switch(inp){
                        case 1:
                            System.out.println("Enter updated syllabus: ");
                            course.syllabus = sc.nextLine();
                            System.out.println("Syllabus has been updated successfully");
                            break;
                        case 2:
                            System.out.println("Enter updated timings: ");
                            course.timings = sc.nextLine();
                            System.out.println("Timings have been updated successfully");
                            break;
                        case 3:
                            System.out.println("Enter updated course credits: ");
                            course.credits = Integer.parseInt(sc.nextLine());
                            System.out.println("Course credit has been updated successfully");
                            break;
                        case 4:
                            System.out.println("Enter updated prerequisite: ");
                            course.prerequisites = sc.nextLine();
                            System.out.println("Prerequisite has been updated successfully");
                            break;
                        case 5:
                            System.out.println("Enter updated enrollment limit: ");
                            enrollmentLimit = sc.nextLine();
                            System.out.println("Enrollment limit has been updated successfully");
                            break;
                        case 6:
                            System.out.println("Enter updated Office hour: ");
                            this.officeHour = sc.nextLine();
                            System.out.println("Office hours have been updated successfully");
                            break;
                        case 7:
                            viewEnrolledStudents(courseCode);
                            assignGrade(courseCode, course);
                            break;
                        case 8:
                            System.out.println("Exiting");
                            return;

                        default:
                            System.out.println("Invalid choice, try again");
                            break;
                    }
                }
            }
        }
    }

    public void viewEnrolledStudents(String courseCode){
        boolean anyEnrolled = false;
        System.out.println("The students enrolled in this course are: ");
        for (Student student : Student.studentList){
            for(Course course : student.registeredCourses){
                if(course.courseCode.equals(courseCode)){
                    anyEnrolled = true;
                    System.out.println("Name: " + student.getName()+ " | email-ID: "+ student.getEmail());
                }
            }
        }
        if(!anyEnrolled){
            System.out.println("No students enrolled");
        }
    }

    public void assignGrade(String courseCode, Course course){
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter name of student for which you would like to upload grade: ");
        String name = sc.nextLine();
        for(Student student : Student.studentList){ // iterartees throguh student to find the desired student whose grade is to be set
            if(student.getName().equals(name)){
                System.out.println("Enter grade from 3-10 which you would like to assign student in this course. Input 0 if failed");
                int grade = Integer.parseInt(sc.nextLine());
                if(grade!=0){
                    for(Grade assigned_grade : student.studentGrade){   // iterates through courses to find the course whose grade is to be set
                        if(assigned_grade.getCourseCode().equals(courseCode)){
                            assigned_grade.setGrade(grade);
                            System.out.println("Grade has been assigned successfully");
                            student.completedCourses.add(course);
                            break;
                        }
                    }
                }
            }
        }
    }

    public void viewFeedback(){
        Scanner sc =  new Scanner(System.in);
        System.out.print("Enter course code for which feedback is to be viewed: ");
        String code = sc.nextLine();
        int i = 1;
        for(Course course : Course.courseList){
            if(course.professor.equals(this.getName()) && course.courseCode.equals(code)) {
                if (course.courseFeedbacks.isEmpty()) {
                    System.out.println("No feedback given");
                } else {
                    System.out.println("The feedback given for this course is: ");
                    for (Feedback<?> feedback : course.courseFeedbacks) {
                        System.out.println(feedback.getUser_feedback());
                        System.out.println("****************************");
                    }
                }
            }
        }
    }
}