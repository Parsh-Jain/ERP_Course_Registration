import java.util.Scanner;
import java.util.ArrayList;

public class Complaints {
    String complaint;
    String status;
    static ArrayList<Complaints> allComplaints = new ArrayList<>();  // stores all complaints which the admin can view and handle

    public Complaints(String complaint, String status){
        this.complaint = complaint;
        this.status = status;
        allComplaints.add(this);
    }

    public String getComplaint() {
        return complaint;
    }

    public void setComplaint(String complaint) {
        this.complaint = complaint;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
