public class Grade {
    int grade;
    String courseCode;
    String courseTitle;

    public Grade(String courseCode, String courseTitle){
        grade = 0;
        this.courseCode = courseCode;
        this.courseTitle = courseTitle;
    }

    public int getGrade(){
        return grade;
    }

    public void setGrade(int grade){
        this.grade = grade;
    }

    public String getCourseCode() {
        return courseCode;
    }

    public String getCourseTitle(){
        return courseTitle;
    }



}
