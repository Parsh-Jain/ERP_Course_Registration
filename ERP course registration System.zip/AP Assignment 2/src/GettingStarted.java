public interface GettingStarted {
    void login(String role);
    void signup(String role);
    void adminLogin();
}
