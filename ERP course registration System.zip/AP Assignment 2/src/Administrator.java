import java.util.Scanner;
import java.util.ArrayList;
import java.util.Scanner;

public class Administrator {
    static String password = "12345";


    public void manageCourses(){
        Scanner sc = new Scanner(System.in);

        while(true){
            System.out.println("What would you like to do in the course catalog?");
            System.out.println("1. View Courses\n2. Add Courses\n3. Delete Courses\n4. Assign Professor to Course\n5. Handle Complaint\n6. Change Student Records/Grades\n7. Exit");
            int inp = Integer.parseInt(sc.nextLine());

            switch(inp){
                case 1:
                    viewCourses();
                    break;
                case 2:
                    addCourses();
                    break;
                case 3:
                    deleteThisCourse();;
                    break;
                case 4:
                    assignProfessor();
                    break;
                case 5:
                    handleComplain();
                    break;
                case 6:
                    changeStudentRecord();
                    break;
                case 7:
                    return;
                default:
                    System.out.println("Invalid choice, try again");
                    break;
            }
        }
    }

    public void viewCourses(){
        for(Course course : Course.courseList){
            System.out.println("Course code: " + course.courseCode);
            System.out.println("Course title: " + course.title);
            System.out.println("Course professor: " + course.professor);
            System.out.println("Course credits: " + course.credits);
            System.out.println("Course prerequisites: " + course.prerequisites);
            System.out.println("Course semester offered: " + course.semOffered);
            System.out.println("Course timings: " + course.timings);
            System.out.println("Course location: " + course.location);
            System.out.println("*************************************");
        }
    }

    public void addCourses(){
        Course course = new Course();
        course.addCourse();
    }

    public void deleteThisCourse(){
        Course course = new Course();
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter code of course which you would like to delete: ");
        String courseCode = sc.nextLine();
        course.deleteCourse(courseCode);
    }

    public void handleComplain() {
        Scanner sc = new Scanner(System.in);

        if (Complaints.allComplaints.isEmpty()) {
            System.out.println("No complaints to handle.");
            return;
        }

        for (Complaints complaint : Complaints.allComplaints) {
            if (complaint.status.equals("Pending")) {
                System.out.println("Complaint: " + complaint.getComplaint());
                System.out.println("Now that the issue has been noted and addressed, would you like to resolve this complaint? Type (yes)/(no)");
                String inp = sc.nextLine();

                if (inp.equalsIgnoreCase("yes")) {
                    complaint.setStatus("Resolved");
                    System.out.println("Complaint has been resolved, going back...");
                }
            }
        }
    }


    public void assignProfessor(){
        Scanner sc = new Scanner(System.in);
        System.out.print("Please type the professor which you would like to assign: ");
        String professor = sc.nextLine();

        for(Professor prof : Professor.professorDetails){
            if(prof.getName().equals(professor)){
                System.out.print("Please type the code of course which you would like to assign to given professor: ");
                String assigned_course = sc.nextLine();
                for(Course course : Course.courseList){
                    if (course.courseCode.equals(assigned_course)){
                        course.professor = professor;
                    }
                }
            }
        }
    }

    public void changeStudentRecord(){
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter name of student whose record you would like to modify: ");
        String name = sc.nextLine();
        boolean found = false;
        for(Student student : Student.studentList){
            if(student.getName().equals(name)){
                found = true;
                System.out.println("Choose what would you like to change: ");
                System.out.println("1. Name\n2. Password\n3. Email-ID\n4. Semester\n5. Assign grade\n6. Calculate CGPA");
                int inp = Integer.parseInt(sc.nextLine());

                switch(inp){
                    case 1:
                        System.out.print("Enter new name: ");
                        String new_name = sc.nextLine();
                        student.setName(new_name);
                        System.out.println("Record changed successfully");
                        break;
                    case 2:
                        System.out.print("Enter new password: ");
                        String new_password = sc.nextLine();
                        student.setPassword(new_password);
                        System.out.println("Record changed successfully");
                        break;
                    case 3:
                        System.out.print("Enter new email-ID: ");
                        String new_email = sc.nextLine();
                        student.setEmail(new_email);
                        System.out.println("Record changed successfully");
                        break;
                    case 4:
                        System.out.print("Enter new semester: ");
                        int new_semester = Integer.parseInt(sc.nextLine());
                        student.setSemester(new_semester);
                        System.out.println("Record changed successfully");
                        break;
                    case 5:
                        assignGrade(student);
                        break;
                    case 6:
                        calculateCGPA(student);
                        break;
                }
            }
        }
        if(!found){
            System.out.println("Student not found");
        }
    }

    public void assignGrade(Student student){
        Scanner sc = new Scanner(System.in);
        System.out.println("Courses registered by student are: ");
        student.viewGrade();
        System.out.print("Enter course code for which grade is to be assigned: ");
        String code = sc.nextLine();

        for(Course course1 : student.registeredCourses){
            if(course1.courseCode.equals(code)){
                System.out.print("Enter grade from 1-10 which you would like to assign student in this course. Grade less than 3 means failed: ");
                int grade = Integer.parseInt(sc.nextLine());
                if(grade>=3){
                    for(Grade assigned_grade : student.studentGrade){   // iterates through courses to find the course whose grade is to be set
                        if(assigned_grade.getCourseCode().equals(code)){
                            assigned_grade.setGrade(grade);
                            System.out.println("Grade has been assigned successfully");
                            student.completedCourses.add(course1);
                            return;
                        }
                    }
                }else{
                    System.out.println("Student failed the course, hence course not completed");
                }

            }
        }
    }

    public void calculateCGPA(Student student) {
        int totalGrade = 0;
        int totalCredits = 0;

        if(student.completedCourses.isEmpty()){
            System.out.println("No courses completed, thus no CGPA can be assigned");
            return;
        }

        for (Course completedCourse : student.completedCourses) {
            int credits = completedCourse.credits;
            for (Grade grade : student.studentGrade) {
                if (grade.getCourseCode().equals(completedCourse.courseCode)) {
                    totalGrade += grade.getGrade() * credits;
                    totalCredits += credits;
                    break;
                }
            }
        }
        float cgpa = (float) totalGrade / totalCredits;
        System.out.println("The CGPA of "+student.getName()+ " is "+cgpa);
        //student.viewGrade();
    }

}
