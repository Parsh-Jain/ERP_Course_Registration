import java.util.Scanner;
import java.util.ArrayList;

public class Course {
    String courseCode;
    String title;
    String professor;
    int credits;
    String prerequisites;
    int semOffered;
    String timings;
    String location;
    String syllabus;
    int enrollment_limit = 3;
    int enrolled_students = 0;

    static ArrayList <Course> courseList = new ArrayList<>();   // where all courses are stored
    public ArrayList <Feedback<?>> courseFeedbacks = new ArrayList<>();

    public Course(String courseCode, String title, String professor, int credits, String prerequisites, int semOffered, String timings, String location, String syllabus, int enrollment_limit) {
        this.courseCode = courseCode;
        this.title = title;
        this.professor = professor;
        this.credits = credits;
        this.prerequisites = prerequisites;
        this.semOffered = semOffered;
        this.timings = timings;
        this.location = location;
        this.syllabus = syllabus;
        this.enrollment_limit = 3;
        courseList.add(this);
        //this.enrolled_students++;
    }

    // default constructor made to make it easier to make course class
    public Course(){
        this.courseCode = "";
        this.title = "";
        this.professor = "";
        this.credits = 0;
        this.prerequisites = "";
        this.semOffered = 0;
        this.timings = "";
        this.location = "";
        this.syllabus = "";
        //courseList.add(this);
    }

    public String getCourseCode(){
        return courseCode;
    }


    public void addCourse(){
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter course code: ");
        courseCode = sc.nextLine();
        System.out.print("Enter course title: ");
        title = sc.nextLine();
        System.out.print("Enter course professor name: ");
        professor = sc.nextLine();
        System.out.print("Enter course credits: ");
        credits = Integer.parseInt(sc.nextLine());
        System.out.print("Enter course prerequisites: ");
        prerequisites = sc.nextLine();
        System.out.print("Enter in which semester is course offered: ");
        semOffered = Integer.parseInt(sc.nextLine());
        System.out.print("Enter course timings: ");
        timings = sc.nextLine();
        System.out.print("Enter course location: ");
        location = sc.nextLine();
        System.out.print("Enter course syllabus: ");
        syllabus = sc.nextLine();

        Course newCourse = new Course(courseCode, title, professor, credits, prerequisites, semOffered, timings, location, syllabus,3);
        //courseList.add(newCourse); // stores in this list after administrator makes a new course
        System.out.println("Course with code "+ courseCode +" has been added successfully");
    }

    public void deleteCourse(String courseCode){
        for(Course del_course : courseList){
            if(del_course.courseCode.equals(courseCode)){
                courseList.remove(del_course);
                System.out.println("Course with code "+ del_course.courseCode + " has been removed");
                break;
            }
        }
    }

    public void addFeedback(Feedback <?> feedback){
        courseFeedbacks.add(feedback);
    }


}