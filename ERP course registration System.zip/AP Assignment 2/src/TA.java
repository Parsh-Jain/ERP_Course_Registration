import java.util.Scanner;
public class TA extends Student{

    public TA(String name, String email, String password, int semester) {
        super(name, email, password, semester);
    }

    @Override
    public String toString() {
        System.out.println("Welcome TA " + getName() + " to the TA-ship portal:");
        return "Your details are: Name: " + getName() + " | Email-ID: " + getEmail();
    }

    public void manageTA_ship(){
        Scanner sc =  new Scanner(System.in);
        System.out.println(this.toString());
        System.out.println("1. View Student Grades\n2. Change Student Grades");
        int inp = sc.nextInt();

        switch (inp){
            case 1:
                viewStudentGrades();
                break;
            case 2:
                changeGrade();
                break;
            default:
                System.out.println("Invalid option. Try again.");
                break;
        }
    }

    public void viewStudentGrades(){
        Scanner sc =  new Scanner(System.in);
        System.out.print("Enter name of student for which grades are to be checked/assigned: ");
        String name = sc.nextLine();

        for(Student student : Student.studentList){
            if(student.getName().equals(name)){
                student.viewGrade();
                break;
            }
        }
        System.out.println("Student not found or has not taken been assigned any grade");
    }

    public void changeGrade(){
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter name of student whose grade you would like to edit: ");
        String name = sc.nextLine();

        for(Student student : Student.studentList){
            if(student.getName().equals(name)){
                student.viewGrade();
                if(student.completedCourses.isEmpty()){
                    break;
                }
                System.out.print("Enter code of course you would like to edit: ");
                String code = sc.nextLine();

                for(Course course1 : student.registeredCourses){
                    if(course1.courseCode.equals(code)){
                        System.out.print("Enter grade from 1-10 which you would like to assign student in this course. Grade less than 3 means failed: ");
                        int grade = Integer.parseInt(sc.nextLine());
                        if(grade>=3){
                            for(Grade assigned_grade : student.studentGrade){   // iterates through courses to find the course whose grade is to be set
                                if(assigned_grade.getCourseCode().equals(code)){
                                    assigned_grade.setGrade(grade);
                                    System.out.println("Grade has been assigned successfully");
                                    student.completedCourses.add(course1);
                                    return;
                                }
                            }
                        }else{
                            System.out.println("Student failed the course, hence course not completed");
                        }

                    }
                }
            }
        }

    }

}
