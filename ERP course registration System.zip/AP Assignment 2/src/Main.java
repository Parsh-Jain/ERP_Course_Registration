import java.time.LocalDate;
import java.util.Scanner;
import java.util.ArrayList;
import static java.lang.System.exit;

public class Main implements GettingStarted {

    static ArrayList<User> allUsers = new ArrayList<>();  // Store all registered users which include students and professors

    public static void main(String[] args) {

        // Prepopulating courses
        Course c1 = new Course("CSE101", "Introduction to Programming", "Shad Akthar", 4, "0", 1, "9.30-11.00 on Monday, Wednesday", "LHC", "None",3);
        Course c2 = new Course("MTH101", "Linear Algebra", "Subhajit", 4, "0", 1, "11.00-12.30 on Monday, Wednesday", "LHC", "None",3);
        Course c3 = new Course("ECE101", "Digital Circuits", "Pravesh Biyani", 4, "0", 1, "9.30-11.00 on Tuesday, Thursday", "LHC", "None",3);
        Course c4 = new Course("DES101", "Human Computer Interaction", "Sonal Keshwani", 4, "0", 1, "9.30-11.00 on Tuesday, Thursday", "LHC", "None",3);
        Course c5 = new Course("SSH101", "Communication Skills", "Payal Mukherji", 4, "0", 1, "3.00-6.00 on Thursday", "LHC", "None",3);

        Course c6 = new Course("CSE201", "Data Structures and Algorithms", "Debarka Sengupta", 4, "CSE101", 2, "10:00-11:30 on Tuesday, Thursday", "LHC", "None",3);
        Course c7 = new Course("MTH201", "Probability and Statistics", "Sanjit Kaul", 4, "0", 2, "5.00-6.00 on Mon and Wed", "LHC", "None",3);
        Course c8 = new Course("ECE102", "Basic Electronics", "Sayan Basu Roy", 4, "0", 2, "11.00-12.00 on Tue, Thur", "Tut room", "None",3);
        Course c9 = new Course("CSE202", "Computer Organisation", "Tammam Tillo", 4, "ECE101", 2, "2.00-3.00 on Mon, Wed", "LHC", "None",3);
        Course c10 = new Course("SSH103", "Critical Thinking", "Aasim Khan", 4, "0", 2, "4.00-5.00 on Mon", "LHC", "None",3);

        Course c11 = new Course("CSE301", "Advanced Programming", "Arun Balaji Buduru", 4, "CSE201", 3, "3:00 - 4:30 on Mon,Wed", "LHC", "None",3);
        Course c12 = new Course("ECE301", "Circuit Design", "Sumit Darak", 4, "CSE202", 3, "5:00 - 6:00 on Fri", "LHC", "None",3);


        // Prepopulating students
        Student s1 = new Student("Karan", "karan23271@iiitd.ac.in", "123", 1);
        Student s2 = new Student("Parsh", "parsh23368@iiitd.ac.in","123",2);
        Student s3 = new Student("Priyanshu", "priyanshu400@iiitd.ac.in", "123", 2);
        Student s4 = new Student("Devesh", "devesh23100@iiitd.ac.in", "123",3);


        s2.completedCourses.add(c1);
        s2.completedCourses.add(c2);
        s2.completedCourses.add(c3);
        s2.completedCourses.add(c4);
        s2.completedCourses.add(c5);

        s3.completedCourses.add(c2);
        s3.completedCourses.add(c3);
        s3.completedCourses.add(c4);
        s3.completedCourses.add(c5);

        s4.completedCourses.add(c6);
        s4.completedCourses.add(c9);



        // Prepopulating professors
        Professor p1 = new Professor("Shad Akthar", "shad@iiitd.ac.in", "123", "Monday 5-6", "100");
        Professor p2 = new Professor("Subhajit", "subhajit@iiitd.ac.in", "123", "Monday 5-6", "100");
        Professor p3 = new Professor("Pravesh Biyani", "pravesh@iiitd.ac.in", "123", "Monday 5-6", "100");
        Professor p4 = new Professor("Tammam Tillo", "tammam@iiitd.ac.in", "123", "Monday 5-6", "100");
        Professor p5 = new Professor("Debarka Sengupta", "debarka@iiitd.ac.in", "123", "Monday 5-6", "100");
        Professor p6 = new Professor("Sanjit Kaul", "sanjit@iiitd.ac.in", "123", "Monday 5-6", "100");
        Professor p7 = new Professor("Sumit Darak", "sumit@iiitd.ac.in", "123","Monday 5-6", "100");
        Professor p8 = new Professor("Payal Mukherji", "payal@iiitd.ac.in", "123","Monday 5-6", "100");

        TA ta1 = new TA("ta1", "ta1", "ta1", 3);

        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.println("Welcome to the University Course Registration System");
            loginOrSignup();
        }
    }

    // Login or Sign-up
    public static void loginOrSignup() {
        Scanner sc = new Scanner(System.in);

        System.out.println("1. Sign up as Student");
        System.out.println("2. Login as Student");
        System.out.println("3. Sign up as Professor");
        System.out.println("4. Login as Professor");
        System.out.println("5. Sign up as TA");
        System.out.println("6. Login as TA");
        System.out.println("7. Login as Administrator");
        System.out.println("8. Exit");

        int inp = Integer.parseInt(sc.nextLine());

        Main main = new Main();  // Creating an instance of main class to access the implemented methods

        switch (inp) {
            case 1:
                main.signup("Student");
                break;
            case 2:
                main.login("Student");
                break;
            case 3:
                main.signup("Professor");
                break;
            case 4:
                main.login("Professor");
                break;
            case 5:
                main.signup("TA");
                break;
            case 6:
                main.login("TA");
                break;
            case 7:
                main.adminLogin();
                break;
            case 8:
                System.out.println("Exiting the system...");
                exit(0);
            default:
                System.out.println("Invalid choice, please try again.");
                break;
        }
    }



    // Implementing the signup method from the GettingStarted interface
    @Override
    public void signup(String user_type) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter Name: ");
        String name = sc.nextLine();
        System.out.print("Enter Email: ");
        String email = sc.nextLine();
        System.out.print("Enter Password: ");
        String password = sc.nextLine();

        if (user_type.equals("Student")) {
            System.out.print("Enter Semester: ");
            int semester = Integer.parseInt(sc.nextLine());
            Student student = new Student(name, email, password, semester);
            allUsers.add(student);
            System.out.println("Student registered successfully!");

        } else if (user_type.equals("Professor")) {
            System.out.print("Enter Office Hours: ");
            String officeHours = sc.nextLine();
            System.out.print("Enter maximum number of students which you would like to take in your assigned course: ");
            String enrollmentLimit = sc.nextLine();
            Professor professor = new Professor(name, email, password, officeHours, enrollmentLimit);
            allUsers.add(professor);
            System.out.println("Professor registered successfully!");
        }
        else if (user_type.equals("TA")) {
            System.out.print("Enter Semester: ");
            int semester = Integer.parseInt(sc.nextLine());
            TA ta = new TA(name, email, password, semester);
            allUsers.add(ta);
            System.out.println("TA registered successfully!");
        }

    }

    // Implementing the login method from the GettingStarted interface
    @Override
    public void login(String role) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter Email: ");
        String email = sc.nextLine();
        System.out.print("Enter Password: ");
        String password = sc.nextLine();

        for (User user : allUsers) {
            if (user.getEmail().equals(email) && user.getPassword().equals(password)) {
                if (role.equals("Student") && user instanceof Student) {
                    System.out.println("Student logged in successfully!");
                    studentMenu((Student) user);
                    return;
                } else if(role.equals("TA") && user instanceof TA){
                    System.out.println("TA logged in successfully!");
                    TaMenu((TA) user);
                    return;
                }
                else if (role.equals("Professor") && user instanceof Professor) {
                    System.out.println("Professor logged in successfully!");
                    professorMenu((Professor) user);
                    return;
                }
            }
        }
        System.out.println("Invalid credentials. Please try again.");
    }

    // Implementing the adminLogin method from the GettingStarted interface
    @Override
    public void adminLogin() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter Administrator Password: ");
        String password = sc.nextLine();
        if (password.equals(Administrator.password)) {
            System.out.println("Administrator logged in successfully!");
            adminMenu();
        } else {
            System.out.println("Invalid password. Try again.");
        }
    }

    // Student interface with all available options
    public static void studentMenu(Student student) {
        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.println("Welcome "+student.getName()+": ");
            System.out.println("1. Add Course");
            System.out.println("2. Remove Course");
            System.out.println("3. View Registered Courses");
            System.out.println("4. View Semester Courses");
            System.out.println("5. View Schedule");
            System.out.println("6. Add Complaint");
            System.out.println("7. View Grades");
            System.out.println("8. View Completed Courses");
            System.out.println("9. Give Course Feedback");
            System.out.println("10. Drop a course");
            System.out.println("11. Logout");

            int option = Integer.parseInt(sc.nextLine());
            switch (option) {
                case 1:
                    student.addCourse();
                    break;
                case 2:
                    System.out.print("Enter Course Code to Remove: ");
                    String courseCode = sc.nextLine();
                    student.removeCourses(courseCode);
                    break;
                case 3:
                    student.viewRegisteredCourses();
                    break;
                case 4:
                    student.viewSemCourses();
                    break;
                case 5:
                    student.viewSchedule();
                    break;
                case 6:
                    student.addComplaint();
                    System.out.println("Complaint registered successfully");
                    break;
                case 7:
                    student.viewGrade();
                    break;
                case 8:
                    student.viewCompletedCourses();
                    break;
                case 9:
                    student.giveFeedback();
                    break;
                case 10:
                    LocalDate currentDate = LocalDate.now();
                    LocalDate dropDeadline = LocalDate.parse("2024-10-03");
                    try {
                        student.dropCourse(currentDate, dropDeadline);
                    } catch (DropDeadlinePassedException e) {
                        System.out.println(e.getMessage());
                    }
                    break;
                case 11:
                    System.out.println("Logging out...");
                    return;
                default:
                    System.out.println("Invalid option. Try again.");
                    break;
            }
        }
    }

    // Professor interface with all available options
    public static void professorMenu(Professor professor) {
        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.println("Welcome professor "+ professor.getName()+":");
            System.out.println("1. View Courses");
            System.out.println("2. Manage Courses");
            System.out.println("3. View Enrolled Students");
            System.out.println("4. View Course Feedback");
            System.out.println("5. Logout");

            int option = Integer.parseInt(sc.nextLine());
            switch (option) {
                case 1:
                    professor.viewCourses();
                    break;
                case 2:
                    professor.manageCourses();
                    break;
                case 3:
                    System.out.print("Enter Course Code: ");
                    String courseCode = sc.nextLine();
                    professor.viewEnrolledStudents(courseCode);
                    break;
                case 4:
                    professor.viewFeedback();
                    break;
                case 5:
                    System.out.println("Logging out...");
                    return;
                default:
                    System.out.println("Invalid option. Try again.");
                    break;
            }
        }
    }

    // Administrator interface with all available options
    public static void adminMenu() {
        Administrator admin = new Administrator();
        admin.manageCourses();
    }

    // interface for TA
    public static void TaMenu(TA ta) {
        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.println("Welcome "+ta.getName()+": ");
            System.out.println("1. Add Course");
            System.out.println("2. Remove Course");
            System.out.println("3. View Registered Courses");
            System.out.println("4. View Semester Courses");
            System.out.println("5. View Schedule");
            System.out.println("6. Add Complaint");
            System.out.println("7. View Grades");
            System.out.println("8. View Completed Courses");
            System.out.println("9. Give Course Feedback");
            System.out.println("10. Enter TA-ship portal");
            System.out.println("11. Logout");

            int option = Integer.parseInt(sc.nextLine());
            switch (option) {
                case 1:
                    ta.addCourse();
                    break;
                case 2:
                    System.out.print("Enter Course Code to Remove: ");
                    String courseCode = sc.nextLine();
                    ta.removeCourses(courseCode);
                    break;
                case 3:
                    ta.viewRegisteredCourses();
                    break;
                case 4:
                    ta.viewSemCourses();
                    break;
                case 5:
                    ta.viewSchedule();
                    break;
                case 6:
                    ta.addComplaint();
                    System.out.println("Complaint registered successfully");
                    break;
                case 7:
                    ta.viewGrade();
                    break;
                case 8:
                    ta.viewCompletedCourses();
                    break;
                case 9:
                    ta.giveFeedback();
                    break;
                case 10:
                    ta.manageTA_ship();
                    break;
                case 11:
                    System.out.println("Logging out...");
                    return;
                default:
                    System.out.println("Invalid option. Try again.");
                    break;
            }
        }
    }

}