import java.time.LocalDate;

public class ExceptionHandling {

    // Handles course registration logic
    public static void registerForCourse(Student student, Course course) {
        try {
            if (course.enrolled_students>course.enrollment_limit) {
                throw new CourseFullException("The course is already full.");
            }
            student.addCourse();
        } catch (CourseFullException e) {
            System.out.println(e.getMessage());
        }
    }
    // Handles login logic
    public static void login(User user, String enteredEmail, String enteredPassword) {
        try {
            if (!user.getEmail().equals(enteredEmail) || !user.getPassword().equals(enteredPassword)) {
                throw new InvalidLoginException("Invalid login credentials");
            }
            //System.out.println("Login successful");
        } catch (InvalidLoginException e) {
            System.out.println(e.getMessage());
        }
    }

    // Handles course drop logic with deadline check
    public static void dropCourse(Student student, LocalDate currentDate, LocalDate dropDeadline) {
        try {
            student.dropCourse(currentDate, dropDeadline);
        } catch (DropDeadlinePassedException e) {
            System.out.println(e.getMessage());
        }
    }


}


class CourseFullException extends Exception {
    public CourseFullException(String message) {
        super(message);
    }
}

class InvalidLoginException extends Exception {
    public InvalidLoginException(String message) {
        super(message);
    }
}

class DropDeadlinePassedException extends Exception {
    public DropDeadlinePassedException(String message) {
        super(message);
    }
}

