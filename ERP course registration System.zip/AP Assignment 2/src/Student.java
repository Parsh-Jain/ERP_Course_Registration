import java.util.ArrayList;
import java.util.Scanner;
import java.time.LocalDate;

public class Student extends User{

    private String name;
    private String email;
    private String password;
    private int semester;
    private int registeredCredits = 0;
    static ArrayList<Student> studentList = new ArrayList<>();

    ArrayList<Course> completedCourses = new ArrayList<>();   // stores all courses completed by student
    ArrayList<Course> registeredCourses = new ArrayList<>();  // courses registered for current sem
    ArrayList<Grade> studentGrade = new ArrayList<>();     // student grade for each course


    public Student(String name, String email, String password, int semester) {
        super(name, email, password);
        this.semester = semester;
        studentList.add(this);
        Main.allUsers.add(this);
    }

//    @Override
//    public void setName(String name) {
//        this.name = name;
//    }
//
//    @Override
//    public void setEmail(String email) {
//        this.email = email;
//    }

    public int getSemester() {
        return semester;
    }

    public void setSemester(int semester) {
        this.semester = semester;
    }


    public void addCourse(){
        Scanner sc = new Scanner(System.in);
        System.out.print("Please enter course code: ");
        String courseCode = sc.nextLine();
        boolean found = false;
        for(Course course : Course.courseList){
            if(course.courseCode.equals(courseCode) && course.semOffered == semester){
                found = true;
                if(course.enrolled_students >= course.enrollment_limit){
                    System.out.println("Maximum number of students already enrolled");
                    break;
                }
                if((preRequisteCheck(course.prerequisites) || course.prerequisites.equals("0")) && registeredCredits <=20){
                    registeredCourses.add(course);
                    course.enrolled_students++;
                    Grade grade = new Grade(courseCode, course.title);
                    studentGrade.add(grade);  // initially grade = 0 is simultaneouly added while adding a course
                    registeredCredits += course.credits;
                    System.out.println("Course with code "+ courseCode + " registered successfully");
                    break;
                }else{
                    System.out.println("Not able to add course as either you don't have required prerequisite, or total credit limit exceeded or not offered in your semester");
                    break;
                }
            }
        }
        if(!found){
            System.out.println("Entered course not found or is not available to you this semester");
        }
    }

    public void removeCourses(String courseCode) {
        if (registeredCourses.isEmpty()) {
            System.out.println("You have no registered courses");
        } else {
            boolean found = false;
            for (int i = 0; i < registeredCourses.size(); i++) {
                Course course = registeredCourses.get(i);
                if (course.courseCode.equals(courseCode)) {
                    found = true;
                    registeredCourses.remove(i);
                    System.out.println("Course with code " + courseCode + " removed");
                    break;
                }
            }
            if (!found) {
                System.out.println("Entered course not found");
            }
        }
    }
    public void viewSemCourses(){
        for(Course course : Course.courseList){
            if(course.semOffered == semester){
                System.out.println("Course code: " + course.courseCode);
                System.out.println("Course title: " + course.title);
                System.out.println("Course professor: " + course.professor);
                System.out.println("Course credits: " + course.credits);
                System.out.println("Course prerequisites: " + course.prerequisites);
                System.out.println("Course semester offered: " + course.semOffered);
                System.out.println("Course timings: " + course.timings);
                System.out.println("Course location: " + course.location);
                System.out.println("*************************************");
            }
        }
    }

    public void viewSchedule(){
        if(registeredCourses.isEmpty()){
            System.out.println("No courses registered");
            return;
        }
        for(Course selected_course : registeredCourses){
            System.out.println("Course name: " + selected_course.title);
            System.out.println("Course professor: " + selected_course.professor);
            System.out.println("Course location: " + selected_course.location);
            System.out.println("Course timings: " + selected_course.timings);
            System.out.println("*************************************");
        }
    }

    public void viewCompletedCourses(){
        if(completedCourses.isEmpty()){
            System.out.println("You have no completed courses");
        }else {
            System.out.println("Your completed courses are: ");
            for (Course comp_course : completedCourses) {
                System.out.println(comp_course.title + " | " + comp_course.courseCode + " | " + comp_course.professor);
            }
        }
    }

    public boolean preRequisteCheck(String courseCode){
        for(Course completed : completedCourses){
            if(completed.courseCode.equals(courseCode)){
                return true;
            }
        }
        return false;
    }

    public void addComplaint(){
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter your complaint: ");
        String complaint = sc.nextLine();
        String status = "Pending";
        Complaints new_complaint = new Complaints(complaint, status);
    }

    public void viewRegisteredCourses(){
        if(registeredCourses.isEmpty()){
            System.out.println("No courses registered");
            return;
        }
        for(Course course : registeredCourses){
            System.out.println("Course code: " + course.courseCode);
            System.out.println("Course title: " + course.title);
            System.out.println("Course professor: " + course.professor);
            System.out.println("Course credits: " + course.credits);
            System.out.println("Course prerequisites: " + course.prerequisites);
            System.out.println("Course semester offered: " + course.semOffered);
            System.out.println("Course timings: " + course.timings);
            System.out.println("Course location: " + course.location);
            System.out.println("*************************************");
        }
    }

    public void regCourses(){
        if(registeredCourses.isEmpty()){
            System.out.println("No courses registered");
            return;
        }
        for(Course course : registeredCourses){
            System.out.println(course.courseCode + " | " + course.title);
        }
    }

    public void viewGrade() {
        System.out.println("Grades for registered courses:");
        for (Grade grade : studentGrade) {
            System.out.println(grade.getCourseCode() + " | " + grade.getCourseTitle() + " | Grade: " + grade.getGrade());
        }
        Administrator admin = new Administrator();
        admin.calculateCGPA(this);
    }

    public void giveFeedback(){
        Scanner sc = new Scanner(System.in);
        this.viewCompletedCourses();
        if(completedCourses.isEmpty()){
            return;
        }

        System.out.print("Enter code of completed course for which feedback is to be given: ");
        String code = sc.nextLine();

        for(Course course : completedCourses){
            if(course.courseCode.equals(code)){
                System.out.println("Choose what would you like to give:\n1. Rating (Give from 1-5)\n2. Review (Give in text format)");
                int inp = Integer.parseInt(sc.nextLine());

                if(inp == 1){
                    System.out.print("Enter your rating: ");
                    int rating = Integer.parseInt(sc.nextLine());
                    Feedback <Integer> feedback = new Feedback<>(rating);
                    System.out.println("Feedback given successfully");
                    course.addFeedback(feedback);
                }else if(inp == 2){
                    System.out.print("Enter feedback in form of text: ");
                    String review = sc.nextLine();
                    Feedback <String> feedback = new Feedback<>(review);
                    System.out.println("Feedback given successfully");
                    course.addFeedback(feedback);
                }else{
                    System.out.println("Incorrect type input given, try again");
                    return;
                }
                break;
            }
        }
    }

    public void dropCourse(LocalDate currentDate, LocalDate dropDeadline) throws DropDeadlinePassedException {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter code of course which you would like to drop: ");
        String code = sc.nextLine();

        if (currentDate.isAfter(dropDeadline)) {
            throw new DropDeadlinePassedException("Cannot drop course as the deadline has passed.");
        }

        removeCourses(code);
        System.out.println("Course dropped successfully.");
    }


}
